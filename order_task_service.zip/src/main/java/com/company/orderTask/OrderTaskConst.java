package com.company.orderTask;

public class OrderTaskConst {
	public static final int RESULT_Success = 0;	
	public static final int RESULT_Error_Fail = 8000;	
	
	//范围6101到7000
	public static final int RESULT_ERROR_START = 8001;
		
}
