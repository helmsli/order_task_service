package com.company.orderTask;
/*
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class RestConfiguration {
	@Bean
	     public RestTemplate restTemplate(SimpleClientHttpRequestFactory httpClientFactory) {
	         RestTemplate restTemplate = new RestTemplate(httpClientFactory);
	         return restTemplate;
	  }
	@Bean
	   public SimpleClientHttpRequestFactory httpClientFactory() {
		return null;
	
	}
}
*/